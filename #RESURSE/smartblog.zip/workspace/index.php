<?php

require_once 'application/init.php';

// create an array to pass things around
$TEMPLATE_VARS = array(
    'pageNotFound' => false,
    'login' => false,
    'register' => false
);

// IF we have page
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$pagePath = APP_PATH . 'pages/' . $page . '.php';

if (file_exists($pagePath)) {
    require_once $pagePath;
} else {
    $TEMPLATE_VARS['templatePath'] = APP_PATH . 'templates/components/not-found.php';
    $TEMPLATE_VARS['pageNotFound'] = true;
}

require_once APP_PATH . 'templates/components/main.php';