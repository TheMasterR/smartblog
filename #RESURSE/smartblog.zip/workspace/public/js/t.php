<?php
	error_reporting(0);
	date_default_timezone_set('Europe/Bucharest');
	$page = $_SERVER['PHP_SELF'];
	$sec = "20";
?>
<!DOCTYPE=html>
<head>
	<title>Clients by MAC-ADDRESS</title>
	<meta charset="UTF-8">
    <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">


	<style>
	body {background-color:black;}
	h1   {color:blue;}
	p    {color:white;}
	ol   {margin-top:40px; position: relative; width: 600px; color:white; list-style:none;}
	li   {margin: 0 0 10px 0; padding:10px; background-color:white; counter-increment: item;}
	li:before {margin-right: 10px; content: counter(item); background: black; border-radius: 100%; color: green; width: 1.2em; text-align: center; display: inline-block;}
	.mac {color:black;}
	</style>

</head>

<body>
<?php
// TP-LINK ROUTER CONFIGURATION
$USERNAME = "themasterr";
$PASSWORD = "MadMaxxRE";
$IP = "snia.go.ro:8081";
$LOGIN_URL = "http://snia.go.ro:8081/userRpm/LoginRpm.htm?Save=Save";
// ASUS REPEATER CONFIGURATION
$URL2 = "http://snia.go.ro:8082/Main_WStatus_Content.asp";
$URL3 = "http://snia.go.ro:8083/Main_WStatus_Content.asp";
$USERNAME2 = "admin";
$PASSWORD2 = "MadMaxxRE";

#PING FUNCTION
function availableUrl($host, $port=80, $timeout=1) {
  $fp = fSockOpen($host, $port, $errno, $errstr, $timeout);
  return $fp!=false;
}


// Script start - mesure the performance!
$rustart = getrusage();


#ENCODE USERNAME:PWD(md5 hash) in B64 for cookie and raw url encode the whole thing to be passed by header.
$ENCODED_COOKIE= rawurlencode("Basic ".base64_encode($USERNAME.":".md5($PASSWORD)));


// Create a header stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"Accept-language: en\r\n" .
              "Cookie: Authorization=".$ENCODED_COOKIE."\r\n" .
	      "Referer: "
  )
);

$context = stream_context_create($opts);

// Open the file using the HTTP headers set above
$file = file_get_contents($LOGIN_URL, false, $context);


$RESPONSE = (explode("/",htmlspecialchars($file)));
$KEY = $RESPONSE[3];



// GET MAC ADDRESS FROM 2.4GHZ WIFI
$URL1 = "http://".$IP."/".$KEY."/userRpm/WlanStationRpm.htm?Page=1";
$referer = "http://snia.go.ro:8081/".$array[3]."/userRpm/WlanStationRpm.htm";
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"Accept-language: en\r\n" .
              "Cookie: Authorization=Basic%20dGhlbWFzdGVycjpkMGI2NzY2ZDNmNGNiY2U5NTI5OWUxZTYyYmFhMzMxMg%3D%3D\r\n" .
	      "Referer: ".$referer
  )
);

$context = stream_context_create($opts);

// Open the file using the HTTP headers set above
$file = file_get_contents($URL1, false, $context);


//http://snia.go.ro:8081/VNOTWVRAROOIDYQA/userRpm/WlanNetworkRpm_5g.htm
//http://snia.go.ro:8081/VNOTWVRAROOIDYQA/userRpm/WlanStationRpm_5g.htm?Page=1
// GET MAC ADDRESS FROM 5GHZ WIFI

$URL1 = "http://".$IP."/".$KEY."/userRpm/WlanStationRpm_5g.htm?Page=1";
$referer = "http://snia.go.ro:8081/".$array[3]."/userRpm/WlanStationRpm_5g.htm";
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"Accept-language: en\r\n" .
              "Cookie: Authorization=Basic%20dGhlbWFzdGVycjpkMGI2NzY2ZDNmNGNiY2U5NTI5OWUxZTYyYmFhMzMxMg%3D%3D\r\n" .
	      "Referer: ".$referer
  )
);

$context = stream_context_create($opts);

// Open the file using the HTTP headers set above and append the data
$file = $file . '<br><br><br>'. file_get_contents($URL1, false, $context);


// GET DATA FROM ASUS REPEATER

$context = stream_context_create(array(
    'http' => array(
        'header'  => "Authorization: Basic " . base64_encode("$USERNAME2:$PASSWORD2")
    )
));

// check if the url1 is up
if (availableUrl("snia.go.ro", 8082) == 1) {
	$data = file_get_contents($URL2, false, $context); // get from url 1
}
// check if the url2 is up
if (availableUrl("snia.go.ro", 8083) == 1) {
	$data = $data . file_get_contents($URL3, false, $context); // get from url 2
}

// sanitize the mac`s to be all with dash
$data = str_replace(":", "-", strtolower($data));

$file = $file . $data; // add the results to the main data var



$result = htmlspecialchars(strtolower($file));

$subject = $result;
$pattern = '/([a-fA-F0-9]{2}[:|\-]?){6}/';
preg_match_all($pattern, substr($subject,3), $matches, PREG_PATTERN_ORDER);

// loop the array and get the relevant macs

echo "<ol class=\"mac\">";
for ($i = 0; $i < count($matches[0]); $i++){

  	switch($matches[0][$i]) {
	    case "a8-9f-ba-28-09-04": echo "<li class=\"mac\" style=\"color:blue;\">".$matches[0][$i]. " - <b>Toth Andrea Carla</b>, Samsung Galaxy Core Prime</li>"; break;
	    case "80-61-8f-23-6c-10": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Edina Marika</b>, Philips</li>"; break;
	    case "5c-0a-5b-31-5f-60": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Maria Beatrix</b>, Samsung Galaxy S3</li>"; break;
	    case "68-76-4f-76-6e-47": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Maria Beatrix</b>, Sony Xperia E</li>"; break;
	    case "a4-f1-e8-ea-b2-60": echo "<li class='mac'>".$matches[0][$i]. " - <b>Furău Claudiu</b>, Apple Iphone 5</li>"; break;
	    case "d0-df-9a-d2-93-67": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Nicolae</b>, Laptop, Asus</li>"; break;
	    case "34-4d-f7-85-3d-65": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Nicolae</b>, LG G3</li>"; break;
	    case "b0-c5-59-1a-08-c9": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Nicolae</b>, Samsung A5</li>"; break;
	    case "34-4d-f7-08-60-f1": echo "<li class='mac'>".$matches[0][$i]. " - <b>Toth Nicolae</b>, LG V300, tab</li>"; break;
	    case "c0-d9-62-8a-75-70": echo "<li class='mac'>".$matches[0][$i]. " - TELEVIZOR <b>PANASONIC</b>, SUS</li>"; break;
	    case "c4-36-6c-64-8a-3e": echo "<li class='mac'>".$matches[0][$i]. " - TELEVIZOR <b>LG, webOS</b>, jos</li>"; break;
	    case "00-22-43-68-2a-28": echo "<li class='mac'>".$matches[0][$i]. " - <bstyle=\"color:red;\">LAPTOP MSI</b>, fete</li>"; break;
	    case "00-50-8d-95-9b-80": echo "<li class='mac'>".$matches[0][$i]. " - <b>PC DESKTOP</b>, BIROU NICU</li>"; break;
	    case "00-50-8d-95-9b-81": echo "<li class='mac'>".$matches[0][$i]. " - <b>PC DESKTOP</b>, BIROU NICU</li>"; break;
	    case "ac-38-70-b6-b9-3d": echo "<li class='mac'>".$matches[0][$i]. " - <b>LENOVO</b>, android</li>"; break;
	    case "54-27-58-29-cf-52": echo "<li class='mac'>".$matches[0][$i]. " - <b>Kercsi</b>, MOTOROLA android</li>"; break;
	    case "ac-9e-17-5b-3b-ed": echo "<li class='mac'>".$matches[0][$i]. " - repeater ASUS, RP-n53, 2.4GHZ</li>"; break;
	    case "ac-9e-17-5b-3b-ef": echo "<li class='mac'>".$matches[0][$i]. " - repeater ASUS, RP-n53, 5GHZ</li>"; break;
	    case "64-51-06-30-9d-c7": echo "<li class='mac'>".$matches[0][$i]. " - <b>DESKTOP PC</b>, BIROU FETE</li>"; break;
	    case "ac-9e-17-5b-3b-ec": echo "<li class='mac'>".$matches[0][$i]. " - <i>ASUS REPEATER 2.4Ghz CLIENTES:</i></li>"; break;
	    case "ac-9e-17-5b-3b-ee": echo "<li class='mac'>".$matches[0][$i]. " - <i>ASUS REPEATER 5Ghz CLIENTES:</i></li>"; break;
	    case "f4-42-8f-93-44-13": echo "<li class='mac'>".$matches[0][$i]. " - <b>Laci</b>, SAMSUNG, Galaxy GRAND</li>"; break;
	    case "90-F6-52-BE-4A-32": echo "<li class='mac'>".$matches[0][$i]. " - <b>router, tp-link</b></li>"; break;
	    case "": echo "<li class='mac'>".$matches[0][$i]. " - </li>"; break;
	    default: echo "<li class='mac'>".$matches[0][$i] . " - <b>unknown</b></li>"; break;
	}
}
echo "</ol>";


//print_r($result);


// Script end
function rutime($ru, $rus, $index) {
    return ($ru["ru_$index.tv_sec"]*1000 + intval($ru["ru_$index.tv_usec"]/1000))
     -  ($rus["ru_$index.tv_sec"]*1000 + intval($rus["ru_$index.tv_usec"]/1000));
}

// display performance stats!
// $ru = getrusage();
// echo "This process used " . rutime($ru, $rustart, "utime") .
//     " ms for its computations\n";
// echo "It spent " . rutime($ru, $rustart, "stime") .
//     " ms in system calls\n";




$today = date("F j, Y, g:i:s a");
echo "<p>Last update: " . $today."</p>";

?>
</body>
</html>