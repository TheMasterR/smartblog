<?php

    error_reporting(E_ALL); // report all erors

    define('APP_PATH', dirname(__FILE__) . '/'); //path catre aplication

