<?php

interface BaseObjectInterface {
    public static function getAll($cond = '');
    public function getBy($field, $value);
    public function save();
}