<?php

class User extends BaseObject {
    protected static $TABLE_NAME = 'users';
    public $id, $name, $password, $email, $type;


    public function getBy($field, $value){
        $query_text = " WHERE `".$field."`='".$value."' LIMIT 1;";
        $data = static::getAll($query_text);

        if ($data && is_array($data) && count($data)>0) {
            $userData       = $data[0];
            $this->id       = $userData['id'];
            $this->name     = $userData['name'];
            $this->email    = $userData['email'];
            $this->password = $userData['password'];
            $this->type     = $userData['type'];
        }

    }

    public function save(){
        if($this->id != null) {
           return $this->saveUser();
        } else {
           return $this->insertUser();
        }
    }
    private function saveUser() {
         $query_text = "UPDATE `".static::$TABLE_NAME."`".
                       " SET name='{$this->name}',".
                       "email='{$this->email}',".
                       "password='{$this->password}'".
                       "type='{$this->type}'".
                       "WHERE id='{$this->id}'";
        $q = self::getDBConnection();
        $data = $q->query($query_text);
        return true;
    }

    private function insertUser() {

        $usersWithSameEmail = self::getAll(" WHERE email='{$this->email}'");
        var_dump($usersWithSameEmail);
        if(count($usersWithSameEmail) == 0)
        {
             $query_text = "INSERT INTO `".static::$TABLE_NAME."`".
                           " SET name='{$this->name}',".
                           "email='{$this->email}',".
                           "password='{$this->password}',".
                           "type='{$this->type}'";
            $q = self::getDBConnection();
            $data = $q->query($query_text);

        } else {
            return false;
            //var_dump('un user cu acelasi email exista deja');
        }
        return true;
    }

}
