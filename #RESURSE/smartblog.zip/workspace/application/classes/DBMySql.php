<?php

class DBMySql implements DBMySqlInterface{
    protected $connection;
    function __constructor(){

    }

    public function connect(){
        $this->connection = mysqli_connect(
            getenv("IP"),
            getenv('C9_USER'),
            "",
            "smartblog"
        );
    }

    public function query($query_text){
        $result=mysqli_query($this->connection,$query_text);
        print_r($query_text);
        //print_r($result);

        if (is_object($result)) {
            $rows = [];
            while($row = mysqli_fetch_array($result,MYSQL_ASSOC)) {
                $rows[] = $row;
            }
            return $rows;
        }

        var_dump($result);
        return true;
    }
}