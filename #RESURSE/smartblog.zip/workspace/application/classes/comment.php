<?php

class Comment extends BaseObject {
    protected static $TABLE_NAME = 'comments';
    public $id, $article_id, $user_id, $comment_content, $date_published;


    public function getBy($field, $value){
        $query_text = " WHERE `".$field."`='".$value."' LIMIT 1;";
        $data = static::getAll($query_text);

        if ($data && is_array($data) && count($data)>0) {
            $userData               = $data[0];
            $this->id               = $userData['id'];
            $this->article_id       = $userData['article_id'];
            $this->user_id          = $userData['user_id'];
            $this->comment_content  = $userData['comment_content'];
            $this->date_published   = $userData['date_published'];
        }

    }

    public function save(){
        if($this->id != null) {
           return $this->saveComment();
        } else {
           return $this->insertComment();
        }
    }
    private function saveComment() {
         $query_text = "UPDATE `".static::$TABLE_NAME."`".
                       " SET article_id='{$this->article_id}',".
                       "user_id='{$this->user_id}',".
                       "comment_content='{$this->comment_content}'".
                       "date_published='{$this->date_published}'".
                       "WHERE id='{$this->id}'";
        $q = self::getDBConnection();
        $data = $q->query($query_text);
        return true;
    }

    private function insertComment() {
         $query_text = "INSERT INTO `".static::$TABLE_NAME."`".
                       " SET article_id='{$this->article_id}',".
                       "user_id='{$this->user_id}',".
                       "comment_content='{$this->comment_content}',".
                       "date_published='{$this->date_published}'";
        $q = self::getDBConnection();
        $data = $q->query($query_text);

        return true;
    }
}
