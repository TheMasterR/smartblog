<?php

class BaseObject implements BaseObjectInterface {
    protected static $DB;
    protected static $TABLE_NAME = '';

    public static function getAll($cond = '') {
        $query_text = "SELECT * FROM `".static::$TABLE_NAME."`".$cond.";";
        var_dump($query_text);
        $q = self::getDBConnection();
        $data = $q->query($query_text);

        return $data;
    }

    public function getBy($field, $value){

    }

    public function save(){

    }

    protected static function getDBConnection(){
        if(self::$DB == null) {
            self::$DB = new DBMySql();
            self::$DB->connect();
        }
        return self::$DB;
    }
}