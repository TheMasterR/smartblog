<?php

class Article extends BaseObject {
    protected static $TABLE_NAME = 'articles';
    public $id,$user_id, $title, $content, $media = "",$date_published = NULL, $date_created, $status = 'draft';


    public function getBy($field, $value){
        $query_text = " WHERE `".$field."`='".$value."' LIMIT 1;";
        $data = static::getAll($query_text);

        if ($data && is_array($data) && count($data)>0) {
            $userData               = $data[0];
            $this->id               = $userData['id'];
            $this->user_id          = $userData['user_id'];
            $this->title            = $userData['title'];
            $this->content          = $userData['content'];
            $this->media            = $userData['media'];
            $this->date_published   = $userData['date_published'];
            $this->date_created     = $userData['date_created'];
            $this->status           = $userData['status'];
        }

    }

    public function save(){
        if($this->id != null) {
           return $this->saveArticle();
        } else {
           return $this->insertArticle();
        }
    }
    private function saveArticle() {
         $query_text = "UPDATE `".static::$TABLE_NAME."`".
                       " SET user_id='{$this->user_id}',".
                       "title='{$this->title}',".
                       "content='{$this->content}',".
                       "media='{$this->media}'".
                       "date_published='{$this->date_published}'".
                       "date_created='{$this->date_created}'".
                       "status='{$this->status}'".
                       "WHERE id='{$this->id}'";
        $q = self::getDBConnection();
        $data = $q->query($query_text);
        return true;
    }

    // private function insertArticle() {
    //     $query_text = "INSERT INTO `".static::$TABLE_NAME."`".
    //                   " SET user_id='{$this->user_id}',".
    //                   "title='{$this->title}',".
    //                   "content='{$this->content}',".
    //                   "media='{$this->media}'".
    //                   "date_published='{$this->date_published}'".
    //                   "date_created='{$this->date_created}'".
    //                   "status='{$this->status}';";
    //     $q = self::getDBConnection();
    //     $data = $q->query($query_text);

    //     var_dump($query_text);

    //     return true;
    // }

     private function insertArticle() {
        $query_text = "INSERT INTO `".static::$TABLE_NAME."`
                        (`id`,
                         `user_id`,
                         `title`,
                         `content`,
                         `media`,
                         `date_published`,
                         `date_created`,
                         `status`) VALUES
                         (NULL,
                         '".$this->user_id."',
                         '".$this->title."',
                         '".$this->content."',
                         '".$this->media."',
                         '".date("Y-m-d", strtotime($this->date_published))."',
                         '".date("Y-m-d H:i:s", strtotime($this->date_created))."',
                         '".$this->status."');";
        $q = self::getDBConnection();
        $data = $q->query($query_text);

        var_dump($query_text);

        return true;
    }

}