<form action="" class="panel" method="post">
    <h1>Add new article</h1>

    <label for="title" class="title">Title</label>
    <input type="title" name="email" id="title" placeholder="Article title here..." />

    <label for="tags" class="tags">Tags</label>
    <input type="tags" name="tags" id="tags" placeholder="Some relevant tags..." />

    <label for="image-upload" class="image-upload">Image</label>
    <input type="file" name="image-upload" id="image-upload" value="Browse..." />

    <label for="article-content" class="article-content">Content</label>
    <textarea class="new-article" id="article-content" placeholder="Your article content here..."></textarea>
<input type="submit" value="Add article" />