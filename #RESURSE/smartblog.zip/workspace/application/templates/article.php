<!--ARTICLE 1 WITH COMMENTS-->
<article class="panel">
    <h1>
        <a href="/?page=article">Grace is the beauty of form under the influence of freedom.</a>
    </h1>
    
    <div class="description">
        <div class="share-buttons">
            <p class="author">by </p><a class="author" href="#" target="_blank">Someone Else</a>
            <a class="date" href="#" target="_blank"><time>01/20/2010</time></a>
            <a class="comments" href="#" target="_blank">3 comments</a>
         <a class="tag" href="#" target="_blank">blog category</a>
        </div>
    </div>
    
    <img src="public/img/grace.jpg" />
    <!--<div class="img" style="background-image:url('public/img/grace.jpg')">-->
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
    
   <div class="social">
        <a class="read-more" href="#" alt="Read More">Read more</a>
        <div class="share">
            <span class="share-button"></span>
            
            <span class="sharingiscaring">
                <p>Share :</p>
                <div class="share-buttons">
                    <a class="facebook" href="#" target="_blank"></a>
                    <a class="twitter" href="#" target="_blank"></a>
                    <a class="pinterest" href="#" target="_blank"></a>
                    <a class="googleplus" href="#" target="_blank"></a>
                </div>
            </span>
        </div>
    </div>
</article>
<!--COMMENTS SECTION OF ARTICLE-->
<h3>Comments</h3>

<div class="panel sp">
    <h4>10 Comments</h4>
    <div class="comment-container">
        <img src="./public/img/thumb.png" alt="Profile iamge">
        <div class="comment-right">
            <div class="top">
                <a href="/profile/user_1">Profile name</a>
                <div class="comment-date">Jul 19. 2016</div>
                <span class="clear"></span>
            </div>
            <div class="comment">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vestibulum diam eu scelerisque eleifend.
            </div>
        </div>
        <span class="clear"></span>
    </div>
    
    <div class="comment-container">
        <img src="./public/img/thumb.png" alt="Profile iamge">
        <div class="comment-right">
            <div class="top">
                <a href="/profile/user_1">Profile name</a>
                <div class="comment-date">Jul 19. 2016</div>
                <span class="clear"></span>
            </div>
            <div class="comment">
                Nullam pulvinar ultricies orci, eget mattis tortor pretium id. Integer hendrerit pretium mollis. Aliquam suscipit porttitor orci id laoreet. Quisque ut nibh ante. Cras varius magna felis, non rhoncus sapien faucibus sit amet.
            </div>
        </div>
        <span class="clear"></span>
    </div>
</div>
<!--END OF COMMENTS SECTION-->
<!--END OF ARTICLE 1 WITH COMMENTS-->