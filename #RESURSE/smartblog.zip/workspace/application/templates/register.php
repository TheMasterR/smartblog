<!--REGISTER FORM-->
<form action="" method="post" class="panel sp">
    <h4>Register an account</h4>
    
    <label for="name" class="name">Name</label>
    <input type="name" name="name" id="name" class="name" placeholder="Enter your name"/>
    
    <label for="email" class="email">Email</label>
    <input type="email" name="email" id="email" placeholder="Your email address..."/>
    
    <label for="password" class="password">Password</label>
    <input type="password" name="password" id="password" placeholder="password"/>
    
    <label for="password2" class="password">Confirm Password</label>
    <input type="password" name="password" id="password2" placeholder="password"/>
    
    <input type="submit" value="Register"/>
</form>
<!--END REGISTER FORM-->