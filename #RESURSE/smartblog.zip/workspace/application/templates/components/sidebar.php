<aside>
    <div class="panel profile">

        <div style="background-image:url('public/img/cover.jpg')">
            <a href="/?page=profile" style="background-image:url('public/img/profile.jpg')"></a>
        </div>

        <h4>Your Name</h4>
        <p>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos.
        </p>
    </div>

    <div class="panel labels">
        <h5>Labels</h5>
        <ul>
            <li><a href="#">business</a></li>
            <li><a href="#">galerry</a></li>
            <li><a href="#">stuff</a></li>
            <li><a href="#">things</a></li>
            <li><a href="#">design</a></li>
        </ul>
    </div>

    <!--ENTER TABS HERE-->
    <div class="panel tabs">
        <div class="tab-border">
            <ul class="tab">
                <li class="selected">Popular</li>
                <li>Recent</li>
                <li>Comments</li>
            </ul>

            <div class="clear"></div>
            <!--THE TAB POST CONTENT-->
                <div class="tab-content">

                    <div class="tab-post">
                        <div class="tab-post-img" style="background-image:url('public/img/profile.jpg')"></div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    </div>
                    <div class="tab-post">
                        <div class="tab-post-img" style="background-image:url('public/img/profile.jpg')"></div>
                        <p>Lorem ipsum dolor sit amet, adipisicing elit.</p>
                    </div>
                    <div class="tab-post">
                        <div class="tab-post-img" style="background-image:url('public/img/profile.jpg')"></div>
                        <p>Lorem ipsum dolor sit amet, </p>
                    </div>
                    <div class="tab-post">
                        <div class="tab-post-img" style="background-image:url('public/img/profile.jpg')"></div>
                        <p>Lorem ipsum dolor sit amet, elit.</p>
                    </div>

                </div>
        </div>
    </div>
    <!--END TABS AREA-->

</aside>