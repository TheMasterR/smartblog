<footer>
    <div class="content">
        &copy;2016 <a href="http://www.smartware-academy.ro" target="_blank">Smartware Academy</a>.
        All rights reserved.
    </div>
</footer>