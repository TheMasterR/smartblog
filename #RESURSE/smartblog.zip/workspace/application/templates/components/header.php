<header>
    <div class="content">
        <a href="/">
            <img src="/public/img/logo.png" alt="Smart logo">
        </a>
        <nav>
            <a href="/">HOME</a>
            <a href="/?page=login">Login</a>
            <a href="/?page=register">Register</a>
            <a href="/?page=article">Article</a>
            <span href="#" class="account">
                <a href="/?page=profile">MY ACCOUNT</a>
                <span class="dropdown">
                    <a href="/?page=new-article">New article</a>
                    <a href="/?page=about-us">About us</a>
                    <a href="/?page=login">Login</a>
                    <a href="/?page=logout">Logout</a>
                </span>
            </span>
            <a href="#" class="search"></a>
        </nav>
    </div>
</header>