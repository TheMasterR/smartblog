<!--LOGIN FORM-->
<form action="" method="post" class="panel sp">
    <h4>Log into your account</h4>

    <label for="email" class="email">Email</label>
    <input type="email" name="email" id="email" placeholder="Your email address..."/>

    <label for="password" class="password">Password</label>
    <input type="password" name="password" id="password" placeholder="password"/>

    <input type="submit" value="Login"/>
</form>
<!--END LOGIN FORM-->