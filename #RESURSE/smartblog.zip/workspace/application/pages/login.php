<?php

$TEMPLATE_VARS['templatePath'] = APP_PATH . 'templates/login.php';
$TEMPLATE_VARS['login'] = true;