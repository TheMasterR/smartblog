<?php

$TEMPLATE_VARS['templatePath'] = APP_PATH . 'templates/new-article.php';
