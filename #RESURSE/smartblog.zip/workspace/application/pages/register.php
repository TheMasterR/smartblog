<?php

$TEMPLATE_VARS['templatePath'] = APP_PATH . 'templates/register.php';
$TEMPLATE_VARS['register'] = true;