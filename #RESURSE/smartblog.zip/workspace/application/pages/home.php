<?php

// aici o sa luam articolele

$TEMPLATE_VARS['templatePath'] = APP_PATH . 'templates/home.php';